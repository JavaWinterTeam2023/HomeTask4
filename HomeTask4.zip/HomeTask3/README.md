# HomeTask3
Nafiseh Askari/7219308-I was responsible for the firts part of the task 3 that i will explain it in my video.

Shirin Babaeikouros/7219095-I was responsible for the second part of the task 3 that i explained it in my video.

Dinh Quan Nguyen/7219253 - My responsible is third part of hometask 3 that i explained it in my video.
