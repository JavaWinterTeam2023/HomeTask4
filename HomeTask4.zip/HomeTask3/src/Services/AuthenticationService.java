package Services;

public class AuthenticationService {
	
	    public boolean authenticateUser(String username, String password) {
	        
	        return false;
	    }
	    public boolean authenticateAdministrator(String username, String password) {
	      
	        return false;
	    }
	

}
