package Test;

import java.util.Random;
import Model.Car;
import Services.ChargingStation;

public class ChargingSimulation {
    public static void main(String[] args) {
        //int numStations = 3;
        //int numCars = 10;

        //ChargingStation[] stations = new ChargingStation[numStations];

        //for (int i = 0; i < numStations; i++) {
        //    stations[i] = new ChargingStation(i);
       // }

        //for (int currentTime = 0; currentTime < 120; currentTime += 10) {
          //  for (int j = 0; j < numCars; j++) {
            //    int carId = new Random().nextInt(100) + 1;
             //   int stationId = new Random().nextInt(numStations);
               // Car car = new Car(carId);
               // int finalCurrentTime = currentTime;

               // new Thread(() -> stations[stationId].addToQueue(car, finalCurrentTime)).start();
            }
        }

