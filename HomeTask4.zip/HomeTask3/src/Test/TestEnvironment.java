package Test;

import java.util.concurrent.Semaphore;
import SystemsLog.*;

import Model.ChargingStation;
import Services.ChargingVehicleService;

public class TestEnvironment {
    public static void main(String[] args) {
        
    	//ChargingStationLog chargingst= new ChargingStationLog();
    	//chargingst.WriteToLogFile("station1", "Charging started successfully.");
    	//chargingst.WriteToLogFile("station2", "Maintenance required.");
         //chargingst.openLogFile(".*Station1.*");
        EnergyManagementLog EnergyRsc= new EnergyManagementLog();
        EnergyRsc.initializeLogsDirectory();
        EnergyRsc.log("System", "System started");
        EnergyRsc.logEquipmentActivity("Solar_Panel", "Charging started");
        EnergyRsc.openRequestedLogFile();

    }
}